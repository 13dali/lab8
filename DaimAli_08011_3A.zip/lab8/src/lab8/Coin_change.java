package lab8;

import java.util.*;


public class Coin_change {
	
             /// dynamic programming algorithm implementation is done in this function.
    public static int dynamic_change(int m,int denom[], int k){
        int C[] = new int[m+1];
        int coin=-1;
        
        C[0] = 0;
        
        int S[] = new int[m+1];
        
        
        S[0] = 0;
        int p=1;
        while(p<=m){
            int minimum = Integer.MAX_VALUE;
            for(int i=0;i<k;i++){
                if(p>=denom[i]){
                    if(C[p-denom[i]]+1 < minimum){
                            minimum = C[p-denom[i]]+1;
                            coin = i;
                        }
                }
                
            
            }
            C[p] = minimum;
            S[p] = coin;
            p++;
        
        }
       
     return C[m];
        
    
    }
    
    //greedy algorithm implementation is done in this function
    public static int greedy_change(int given_denom[],int given_amount){
       
       int coin_counter=0;
       List<Integer> select_coin = new ArrayList<Integer>();
       
       int denom_max=-1;
        Arrays.sort(given_denom);
        int total_array = given_denom.length;
          //check for the valid input      
        if(given_amount<=0 || given_amount < given_denom[total_array-1]){
           System.out.println("Invalid given_amount cant't have given_denominations");
           return 0;
        }
        while(given_amount!=0){
            //find the largest given_denom that is <=given_amount
            try{
            	int j=0;
            	while(j<total_array){
                    if(given_denom[j]<=given_amount){
                    denom_max = given_denom[j];
                    }
                    j++;
            }
            //here addition of the selected coins
            int denom_counter = given_amount / denom_max;
            //total coins addition
            int i=0;
            while(i<denom_counter){
           select_coin.add(denom_max);
           i++;
         }
           coin_counter+=denom_counter;
           given_amount = given_amount % denom_max;
           
           
           }catch(Exception e){
               System.out.println();
           }
            
            
        }
      
        return  coin_counter;
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
         //given_denominations given
         int coins[] = {1,5,10,25};
         int given_amount = 55;//change for this given_amount
        System.out.println("given_amount: "+given_amount);
        System.out.println("Greedy_change result:");
        System.out.println("Total number of selected coins are: "+ greedy_change(coins,given_amount));
        System.out.println(); 
        System.out.println("Dynamic_change result:");
        System.out.println("Total number of selected coins are: "+dynamic_change(given_amount,coins, coins.length));
        
        // here search foe the 10 numbers for which the dynamic programming gives optimal solution.
        int counter=0;
        int initial = 40;
        int array_greedy_optimal[] = new int[10];
        while(counter<10){
            given_amount = initial;
            int result_greedy = greedy_change(coins,given_amount);
            int result_dynamic = dynamic_change(given_amount,coins, coins.length);
            
            if(result_dynamic<result_greedy){
                array_greedy_optimal[counter++]=given_amount;
            }
            
            initial+=12;
        }
        System.out.println();
        System.out.println("dynamic programming is optimal for 10 optimal numbers are:");
        int i=0;
        while(i<10)
        {
            System.out.println(array_greedy_optimal[i]);
            i++;
        }
   }
    
}
