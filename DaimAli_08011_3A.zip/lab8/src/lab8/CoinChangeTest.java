package lab8;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Daim Ali
 */
public class CoinChangeTest {
    
    public CoinChangeTest() {
    }
    
    /**
     * Test of dynamic_change method, of class Coin_change.
     */
    @Test
    public void testing_dynamic_change() {
        System.out.println("dynamic_Coin change executed:");
        int m = 40;
        int[] denom = {1,5,10,25};
        int p = 5;
        int result_expected = 2;
        int obtained_result = Coin_change.dynamic_change(m, denom, p);
        assertEquals(result_expected, obtained_result);
       
    }
    
    
    /**
     * Test of greedy_change method, of class Coin_change.
     */
    @Test
    public void testing_greedy() {
        System.out.println("greedy_Coin change executed:");
        int[] given_denom = {1,5,10,25};
        int given_amount = 40;
        int result_expected = 3;
        int obtained_result = Coin_change.greedy_change(given_denom, given_amount);
        assertEquals(result_expected, obtained_result);
        
    }

    

    
}
